#pragma once

namespace il2cpp
{
namespace os
{
namespace Image
{
    void* GetImageBase();
}
}
}
