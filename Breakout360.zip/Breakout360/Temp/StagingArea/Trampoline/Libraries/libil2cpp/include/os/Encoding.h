#pragma once
#include <string>

namespace il2cpp
{
namespace os
{
namespace Encoding
{
    std::string GetCharSet();
}
}
}
