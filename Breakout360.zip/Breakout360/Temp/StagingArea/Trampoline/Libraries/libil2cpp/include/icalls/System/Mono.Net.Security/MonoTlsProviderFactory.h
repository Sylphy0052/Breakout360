#pragma once

#if NET_4_0

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace Mono
{
namespace Net
{
namespace Security
{
    class LIBIL2CPP_CODEGEN_API MonoTlsProviderFactory
    {
    public:
        static bool IsBtlsSupported();
    };
} // namespace Security
} // namespace Net
} // namespace Mono
} // namespace System
} // namespace icalls
} // namespace il2cpp

#endif
